<?php
return [
    'host' => 'localhost',
    'user' => 'root',
    'pass' => '',
    'db'   => 'db_eparking'
];